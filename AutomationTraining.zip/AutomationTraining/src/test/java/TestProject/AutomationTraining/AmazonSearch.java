package TestProject.AutomationTraining;



import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;


public class AmazonSearch {
	
	WebDriver driver;
	String actualdata="Camera";
	ExtentHtmlReporter extenthtmlReport;
	ExtentReports extentReports;
	ExtentTest extentTest;
	
	@BeforeTest
	public void setUp() {
		
		String path=System.getProperty("user.dir");
		
		System.setProperty("webdriver.chrome.driver", path+"\\src\\main\\driver\\chromedriver.exe");
		
		ChromeOptions options=new ChromeOptions();
		options.setExperimentalOption("useAutomationExtension", false);
		driver=new ChromeDriver(options);
		
		driver.manage().window().maximize();
		
		driver.navigate().to("https://www.amazon.in/");
		
		extenthtmlReport=new ExtentHtmlReporter(path+"\\reports\\extentreport.html");
		extenthtmlReport.config().setDocumentTitle("Automation Report");
		extenthtmlReport.config().setReportName("Amazon Search Report");
		extenthtmlReport.config().setTheme(Theme.DARK);
		extentReports=new ExtentReports();
		extentReports.attachReporter(extenthtmlReport);
		
		extentReports.setSystemInfo("hostname", "DELL-PC");
		extentReports.setSystemInfo("OS", "Windows");

		
	
	}
	
	@Test(priority = 1)
	public void amazonSearch() throws IOException {
		extentTest=extentReports.createTest("Amazon Search");
		extentTest.log(Status.INFO, "Amazon Page Opened");
		driver.findElement(By.id("twotabsearchtextbox")).sendKeys(actualdata+Keys.ENTER);
		extentTest.log(Status.INFO, "Searched amazon with "+actualdata);
		

		
	}
	
	@Test(priority = 0)
	public void amazonTitle() throws IOException {
		extentTest=extentReports.createTest("Amazon Title Verification");
		extentTest.log(Status.INFO, "Amazon Page Opened");
		Assert.assertEquals(driver.getTitle(), "Online Shopping site in India");
	

		
	}
	
	
	@AfterMethod()
	public void logStatus(ITestResult result) throws IOException {
		if(result.getStatus()==ITestResult.SUCCESS) {
			extentTest.log(Status.PASS, result.getName()+" passed");
			extentTest.addScreenCaptureFromPath(takeScreenshot(driver));
		}
		
		if(result.getStatus()==ITestResult.FAILURE) {
			extentTest.log(Status.FAIL, result.getName()+" failed");
			extentTest.addScreenCaptureFromPath(takeScreenshot(driver));
		}
		
	}

	
	@AfterTest
	public void teardown() {
		driver.close();
		extentReports.flush();
	}
	
	
	public String takeScreenshot(WebDriver driver) throws IOException {
        String dateName= new SimpleDateFormat("MMddhhmmss").format(new Date());
        TakesScreenshot ts=(TakesScreenshot) driver;
        File src=ts.getScreenshotAs(OutputType.FILE);
        String fileName=System.getProperty("user.dir")+"\\output\\"+dateName+".png";
        File destination=new File(fileName);
        FileUtils.copyFile(src,destination);
        return fileName;


    }
	
	


}
