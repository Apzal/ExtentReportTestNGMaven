package stepdefinitions;

import org.openqa.selenium.WebDriver;

public class BaseClass {
    public  WebDriver driver;
}
