package stepdefinitions;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.cucumber.datatable.DataTable;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.List;


public class MyStepdefs {

    private BaseClass base;

    public MyStepdefs(BaseClass base) {
        this.base = base;
    }





    @Given("I open Amazon")
    public void iOpenAmazon() {
        base.driver.navigate().to("https://www.amazon.in/");
        System.out.println(base.driver.getTitle());
    }

    @And("I enter {string} in searchbox")
    public void iEnterCameraInSearchbox(String product) {
        base.driver.findElement(By.id("twotabsearchtextbox")).sendKeys(product+ Keys.ENTER);

    }


    @Then("I should see the results for {string}")
    public void iShouldSeeTheResultsForCamera(String product) {
        WebDriverWait wait=new WebDriverWait(base.driver,10);

        WebElement element=wait.until(ExpectedConditions.visibilityOf(base.driver.findElement(By.xpath("//span[contains(text(),'"+product+"')]"))));
        String actualresult=element.getText();
        actualresult=actualresult.replace("\"","");
        System.out.println(actualresult);
        Assert.assertEquals("Expected "+product+" but found "+actualresult,actualresult,product);
    }

}
