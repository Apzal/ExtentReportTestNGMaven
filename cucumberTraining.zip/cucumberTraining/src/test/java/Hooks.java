import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import stepdefinitions.BaseClass;

public class Hooks{

    private BaseClass base;

    public Hooks(BaseClass base) {
        this.base = base;
    }

    @Before
    public void openBrowser(Scenario scenario){

        System.out.println("Running Scenario "+scenario.getName());
        String path=System.getProperty("user.dir");

        path=path+"\\src\\test\\driver\\chromedriver.exe";
        System.out.println(path);
        System.setProperty("webdriver.chrome.driver",path);
        ChromeOptions options=new ChromeOptions();
        options.setExperimentalOption("useAutomationExtension",false);
        base.driver=new ChromeDriver(options);
        base.driver.manage().window().maximize();

    }



    @After
    public void tearDown(Scenario scenario){
        System.out.println(scenario.getStatus());


        base.driver.close();
    }
}
